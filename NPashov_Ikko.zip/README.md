# Ikko-Database
A simple database implementation for a university assignment.

Build and run:
```
mkdir build
cd build
cmake ..
make
./Ikko
```
Tested with g++ on Arch Linux
