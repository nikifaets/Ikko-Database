# Ikko-Database
A simple database implementation for an university assignment.
Documentation coming soon
