#include "RecordInvalid.h"

Type RecordInvalid::get_type(){

    return type;
}

void RecordInvalid::parse(std::string value){}
std::string RecordInvalid::to_string(){}